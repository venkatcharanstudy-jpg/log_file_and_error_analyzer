"""Participant 2 - Counter-based analysis of parsed events."""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Iterable, List, Optional

from .parser import LogEvent

logger = logging.getLogger(__name__)

ERROR_LEVELS = frozenset({"ERROR", "CRITICAL"})
WARNING_LEVELS = frozenset({"WARNING"})


@dataclass
class PatternInfo:
    """Metadata remembered for each distinct message signature."""
    level: str
    module: str
    category: str
    first_seen: datetime
    last_seen: datetime
    example: str


@dataclass
class TopEntry:
    rank: int
    signature: str
    count: int
    percent: float
    level: str
    module: str
    category: str
    first_seen: datetime
    last_seen: datetime
    example: str


@dataclass
class AnalysisResult:
    total_events: int = 0
    level_counts: Counter = field(default_factory=Counter)
    error_counts: Counter = field(default_factory=Counter)      # signature -> n
    warning_counts: Counter = field(default_factory=Counter)
    module_errors: Counter = field(default_factory=Counter)
    module_warnings: Counter = field(default_factory=Counter)
    category_errors: Counter = field(default_factory=Counter)
    hourly_errors: Counter = field(default_factory=Counter)     # "YYYY-MM-DD HH:00"
    error_patterns: Dict[str, PatternInfo] = field(default_factory=dict)
    warning_patterns: Dict[str, PatternInfo] = field(default_factory=dict)
    first_timestamp: Optional[datetime] = None
    last_timestamp: Optional[datetime] = None

    # ---- derived numbers --------------------------------------------------
    @property
    def error_count(self) -> int:
        return sum(self.level_counts[lvl] for lvl in ERROR_LEVELS)

    @property
    def warning_count(self) -> int:
        return sum(self.level_counts[lvl] for lvl in WARNING_LEVELS)

    @property
    def error_rate(self) -> float:
        """Fraction of all events that are errors (0..1)."""
        return self.error_count / self.total_events if self.total_events else 0.0

    @property
    def unique_errors(self) -> int:
        return len(self.error_counts)

    @property
    def peak_error_hour(self):
        """(hour_label, count) of the busiest error hour, or None."""
        top = self.hourly_errors.most_common(1)
        return top[0] if top else None

    # ---- ranking ---------------------------------------------------------
    @staticmethod
    def _top(counter: Counter, patterns: Dict[str, PatternInfo], n: int) -> List[TopEntry]:
        total = sum(counter.values()) or 1
        entries = []
        for rank, (sig, count) in enumerate(counter.most_common(n), start=1):
            info = patterns[sig]
            entries.append(TopEntry(
                rank, sig, count, 100.0 * count / total, info.level, info.module,
                info.category, info.first_seen, info.last_seen, info.example,
            ))
        return entries

    def top_errors(self, n: int = 5) -> List[TopEntry]:
        return self._top(self.error_counts, self.error_patterns, n)

    def top_warnings(self, n: int = 5) -> List[TopEntry]:
        return self._top(self.warning_counts, self.warning_patterns, n)


def _record(counter: Counter, patterns: Dict[str, PatternInfo], event: LogEvent) -> None:
    sig = event.signature
    counter[sig] += 1
    info = patterns.get(sig)
    if info is None:
        patterns[sig] = PatternInfo(
            event.level, event.module, event.category,
            event.timestamp, event.timestamp, event.message,
        )
    else:
        info.first_seen = min(info.first_seen, event.timestamp)
        info.last_seen = max(info.last_seen, event.timestamp)


def analyze(events: Iterable[LogEvent]) -> AnalysisResult:
    """Consume an iterable (usually the ``read_log`` generator) in one pass."""
    result = AnalysisResult()
    for ev in events:
        result.total_events += 1
        result.level_counts[ev.level] += 1

        if result.first_timestamp is None or ev.timestamp < result.first_timestamp:
            result.first_timestamp = ev.timestamp
        if result.last_timestamp is None or ev.timestamp > result.last_timestamp:
            result.last_timestamp = ev.timestamp

        if ev.level in ERROR_LEVELS:
            _record(result.error_counts, result.error_patterns, ev)
            result.module_errors[ev.module] += 1
            result.category_errors[ev.category] += 1
            result.hourly_errors[ev.timestamp.strftime("%Y-%m-%d %H:00")] += 1
        elif ev.level in WARNING_LEVELS:
            _record(result.warning_counts, result.warning_patterns, ev)
            result.module_warnings[ev.module] += 1

    logger.info(
        "Analysis complete: %d events, %d errors (%d unique), %d warnings",
        result.total_events, result.error_count, result.unique_errors, result.warning_count,
    )
    return result


def find_alerts(
    result: AnalysisResult,
    error_rate_threshold: float = 0.15,
    repeat_threshold: int = 10,
    burst_factor: float = 2.0,
) -> List[str]:
    """Simple monitoring rules that turn numbers into operational alerts."""
    alerts: List[str] = []

    if result.level_counts["CRITICAL"]:
        alerts.append(f"{result.level_counts['CRITICAL']} CRITICAL event(s) present")

    if result.error_rate > error_rate_threshold:
        alerts.append(
            f"High error rate: {result.error_rate:.1%} (threshold {error_rate_threshold:.0%})"
        )

    for sig, count in result.error_counts.most_common():
        if count < repeat_threshold:
            break
        alerts.append(f"Recurring error x{count}: {sig}")

    if result.hourly_errors:
        avg = sum(result.hourly_errors.values()) / len(result.hourly_errors)
        hour, peak = result.peak_error_hour
        if len(result.hourly_errors) > 1 and peak >= burst_factor * avg and peak >= repeat_threshold:
            alerts.append(f"Error burst in hour {hour}: {peak} errors (avg {avg:.1f}/h)")

    for message in alerts:
        logger.warning("ALERT: %s", message)
    return alerts
