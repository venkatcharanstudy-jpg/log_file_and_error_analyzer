"""Participant 2 - console summary, text report and CSV exports."""
from __future__ import annotations

import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .analyzer import AnalysisResult, TopEntry
from .parser import ParseStats

logger = logging.getLogger(__name__)

WIDTH = 72
TS_FMT = "%Y-%m-%d %H:%M:%S"


def _bar(count: int, maximum: int, width: int = 28) -> str:
    return "#" * (round(width * count / maximum) if maximum else 0)


def _truncate(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 3] + "..."


def _counter_block(title: str, counter, limit: int = 5) -> List[str]:
    lines = [title]
    if not counter:
        return lines + ["  (none)"]
    maximum = counter.most_common(1)[0][1]
    for key, count in counter.most_common(limit):
        lines.append(f"  {key:<24} {count:>5}  {_bar(count, maximum)}")
    return lines


def _top_block(title: str, entries: List[TopEntry]) -> List[str]:
    lines = [title]
    if not entries:
        return lines + ["  (none)"]
    for e in entries:
        lines.append(f"  {e.rank:>2}. x{e.count:<4} ({e.percent:4.1f}%)  [{e.category}] {e.module}")
        lines.append(f"      {_truncate(e.signature, WIDTH - 6)}")
        lines.append(f"      first {e.first_seen:{TS_FMT}}  last {e.last_seen:{TS_FMT}}")
    return lines


def build_report(
    result: AnalysisResult,
    alerts: List[str],
    *,
    source: str = "",
    stats: Optional[ParseStats] = None,
    top_n: int = 5,
) -> str:
    """Return the full human-readable report as one string."""
    rule, thin = "=" * WIDTH, "-" * WIDTH
    out: List[str] = [rule, " LOG FILE ANALYSIS REPORT".ljust(WIDTH), rule]

    out.append(f"Source file : {source}")
    out.append(f"Generated   : {datetime.now():{TS_FMT}}")
    if result.first_timestamp:
        out.append(f"Log period  : {result.first_timestamp:{TS_FMT}} -> {result.last_timestamp:{TS_FMT}}")
    out += ["", "OVERVIEW", thin]
    out.append(f"Total events   : {result.total_events}")
    out.append(f"Errors         : {result.error_count} ({result.error_rate:.1%}), {result.unique_errors} unique")
    out.append(f"Warnings       : {result.warning_count}")
    if stats:
        out.append(
            f"Lines read     : {stats.total_lines} "
            f"(malformed: {stats.malformed}, stack-trace lines: {stats.continuation})"
        )
    if result.peak_error_hour:
        hour, count = result.peak_error_hour
        out.append(f"Peak error hour: {hour} ({count} errors)")

    out += ["", *_counter_block("EVENTS BY LEVEL", result.level_counts, 10)]
    out += ["", *_top_block(f"TOP {top_n} RECURRING ERRORS", result.top_errors(top_n))]
    out += ["", *_top_block(f"TOP {top_n} RECURRING WARNINGS", result.top_warnings(top_n))]
    out += ["", *_counter_block("ERRORS BY MODULE", result.module_errors)]
    out += ["", *_counter_block("ERRORS BY CATEGORY", result.category_errors)]
    out += ["", *_counter_block("ERRORS BY HOUR", result.hourly_errors, 24)]

    out += ["", "ALERTS", thin]
    out += [f"  ! {a}" for a in alerts] if alerts else ["  No alerts - system looks healthy."]
    out.append(rule)
    return "\n".join(out)


def print_console_summary(report_text: str) -> None:
    print(report_text)


def write_text_report(report_text: str, path: Path) -> Path:
    path = Path(path)
    path.write_text(report_text + "\n", encoding="utf-8")
    logger.info("Text report written: %s", path)
    return path


def write_top_errors_csv(result: AnalysisResult, path: Path, top_n: int = 10) -> Path:
    """Top recurring errors, one row each - easy to open in Excel."""
    path = Path(path)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["rank", "count", "percent_of_errors", "level", "module",
                         "category", "first_seen", "last_seen", "pattern", "example"])
        for e in result.top_errors(top_n):
            writer.writerow([e.rank, e.count, f"{e.percent:.1f}", e.level, e.module,
                             e.category, f"{e.first_seen:{TS_FMT}}", f"{e.last_seen:{TS_FMT}}",
                             e.signature, e.example])
    logger.info("Top-errors CSV written: %s", path)
    return path


def write_summary_csv(result: AnalysisResult, path: Path) -> Path:
    """Flat metric,value summary including per-level/module/category counts."""
    path = Path(path)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["section", "metric", "value"])
        writer.writerow(["overview", "total_events", result.total_events])
        writer.writerow(["overview", "error_count", result.error_count])
        writer.writerow(["overview", "warning_count", result.warning_count])
        writer.writerow(["overview", "unique_errors", result.unique_errors])
        writer.writerow(["overview", "error_rate_percent", f"{result.error_rate * 100:.2f}"])
        for section, counter in (("level", result.level_counts),
                                 ("module_errors", result.module_errors),
                                 ("category_errors", result.category_errors),
                                 ("hourly_errors", result.hourly_errors)):
            for key, count in counter.most_common():
                writer.writerow([section, key, count])
    logger.info("Summary CSV written: %s", path)
    return path
