"""Self-contained HTML dashboard (no external files, opens in any browser)."""
from __future__ import annotations

import logging
from datetime import datetime
from html import escape
from pathlib import Path

logger = logging.getLogger(__name__)
TS = "%Y-%m-%d %H:%M:%S"

CSS = """
:root{--bg:#f6f7f9;--card:#fff;--text:#1d2330;--muted:#6b7385;--line:#e3e6ec;
--err:#d64545;--warn:#d9922b;--ok:#2f9e6b;--info:#3b7ddd}
@media (prefers-color-scheme:dark){:root{--bg:#14171d;--card:#1d222c;--text:#e8ebf2;
--muted:#99a1b3;--line:#2c3340}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);
font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:1000px;margin:0 auto;padding:24px 16px 48px}
h1{margin:0 0 4px;font-size:24px}h2{font-size:16px;margin:0 0 12px}
.sub{color:var(--muted);font-size:13px;margin-bottom:20px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px}
.card,.panel{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.panel{margin-bottom:16px}
.card b{display:block;font-size:26px}.card span{color:var(--muted);font-size:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}
.row{display:grid;grid-template-columns:150px 1fr 40px;gap:8px;align-items:center;margin:5px 0;font-size:13px}
.row i{display:block;height:10px;border-radius:5px;background:var(--info)}
.row.e i{background:var(--err)}.row.w i{background:var(--warn)}
.row em{font-style:normal;text-align:right;color:var(--muted)}
.row s{text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.scroll{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:7px 8px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--muted);font-weight:600}
code{font:12px ui-monospace,Consolas,monospace}
.tag{background:var(--bg);border:1px solid var(--line);border-radius:999px;padding:1px 8px;font-size:11px}
.alert{border-left:4px solid var(--err);padding:6px 10px;margin:6px 0;background:var(--bg);border-radius:4px}
.ok{border-left-color:var(--ok)}
"""


def _bars(counter, limit, css="") -> str:
    if not counter:
        return '<p class="sub">(none)</p>'
    top = counter.most_common(limit)
    mx = top[0][1] or 1
    return "".join(
        f'<div class="row {css}"><s title="{escape(str(k))}">{escape(str(k))}</s>'
        f'<i style="width:{max(2, 100 * v // mx)}%"></i><em>{v}</em></div>'
        for k, v in top
    )


def _hourly(hourly) -> str:
    if not hourly:
        return '<p class="sub">(none)</p>'
    mx = max(hourly.values())
    return "".join(
        f'<div class="row e"><s>{escape(k)}</s><i style="width:{max(2, 100 * v // mx)}%"></i><em>{v}</em></div>'
        for k, v in sorted(hourly.items()))


def _table(entries) -> str:
    if not entries:
        return '<p class="sub">(none)</p>'
    rows = "".join(
        f"<tr><td>{e.rank}</td><td><b>{e.count}</b><br><span class='sub'>{e.percent:.1f}%</span></td>"
        f"<td><code>{escape(e.signature)}</code><br><span class='sub'>{escape(e.module)} "
        f"<span class='tag'>{escape(e.category)}</span></span></td>"
        f"<td class='sub'>{e.first_seen:{TS}}<br>{e.last_seen:{TS}}</td></tr>"
        for e in entries
    )
    return ("<div class='scroll'><table><tr><th>#</th><th>Count</th><th>Pattern</th>"
            f"<th>First / last seen</th></tr>{rows}</table></div>")


def write_html_report(result, alerts, path, *, source="", stats=None, top_n=5) -> Path:
    peak = result.peak_error_hour
    period = (f"{result.first_timestamp:{TS}} &rarr; {result.last_timestamp:{TS}}"
              if result.first_timestamp else "n/a")
    alert_html = ("".join(f'<div class="alert">{escape(a)}</div>' for a in alerts)
                  or '<div class="alert ok">No alerts - system looks healthy.</div>')
    malformed = f" &middot; {stats.malformed} malformed lines skipped" if stats else ""
    cards = [
        (result.total_events, "Total events"),
        (f"{result.error_count} ({result.error_rate:.1%})", "Errors"),
        (result.warning_count, "Warnings"),
        (result.unique_errors, "Unique errors"),
        (peak[0][-8:] if peak else "-", f"Peak error hour ({peak[1]} errors)" if peak else "Peak error hour"),
    ]
    cards_html = "".join(f'<div class="card"><b>{v}</b><span>{l}</span></div>' for v, l in cards)

    page = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Log Analysis Report</title><style>{CSS}</style></head><body><main>
<h1>Log Analysis Report</h1>
<div class="sub">{escape(str(source))} &middot; {period}{malformed}<br>
Generated {datetime.now():{TS}}</div>
<div class="cards">{cards_html}</div>
<div class="panel"><h2>Alerts</h2>{alert_html}</div>
<div class="panel"><h2>Top {top_n} recurring errors</h2>{_table(result.top_errors(top_n))}</div>
<div class="panel"><h2>Top {top_n} recurring warnings</h2>{_table(result.top_warnings(top_n))}</div>
<div class="grid">
<div class="panel"><h2>Events by level</h2>{_bars(result.level_counts, 10)}</div>
<div class="panel"><h2>Errors by category</h2>{_bars(result.category_errors, 10, "e")}</div>
<div class="panel"><h2>Errors by module</h2>{_bars(result.module_errors, 10, "e")}</div>
<div class="panel"><h2>Errors by hour</h2>{_hourly(result.hourly_errors)}</div>
</div></main></body></html>"""
    path = Path(path)
    path.write_text(page, encoding="utf-8")
    logger.info("HTML report written: %s", path)
    return path