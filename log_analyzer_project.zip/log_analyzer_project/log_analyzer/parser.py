"""Participant 1 - file reading, parsing and event classification.

Key ideas
---------
* ``read_log`` is a *generator*: it streams one event at a time, so a multi-GB
  log never has to fit in memory.
* Fields are extracted with regular expressions (two supported line formats).
* Stack-trace lines that follow an event are attached to it as ``details``.
* Every event is classified into a category (Database, Network, ...).
* The message is normalised (numbers/IPs/paths replaced by placeholders) so
  that "timeout after 30s" and "timeout after 45s" count as the same error.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------
# Constants / regular expressions
# --------------------------------------------------------------------------
LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
LEVEL_ALIASES = {"WARN": "WARNING", "ERR": "ERROR", "FATAL": "CRITICAL"}

_TS = r"\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[,.]\d{1,6})?"

# Format A:  2026-10-19 08:15:32,123 | ERROR | database.connection | message
PIPE_RE = re.compile(
    rf"^(?P<ts>{_TS})\s*\|\s*(?P<level>[A-Za-z]+)\s*\|\s*"
    r"(?P<module>[\w.\-]+)\s*\|\s*(?P<message>.*)$"
)
# Format B:  2026-10-19 08:15:32 [ERROR] database.connection: message
BRACKET_RE = re.compile(
    rf"^(?P<ts>{_TS})\s+\[(?P<level>[A-Za-z]+)\]\s+"
    r"(?P<module>[\w.\-]+):\s*(?P<message>.*)$"
)
LINE_PATTERNS = (PIPE_RE, BRACKET_RE)

CONTINUATION_RE = re.compile(
    r"^(\s+|Traceback\b|Caused by\b|[\w.]+(Error|Exception)\b)"
)

# (compiled regex, placeholder) - order matters (IP before plain numbers).
_NORMALIZERS = (
    (re.compile(r"\b[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\b"), "<UUID>"),
    (re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b"), "<IP>"),
    (re.compile(r"\b0x[0-9a-fA-F]+\b"), "<HEX>"),
    (re.compile(r"(?:[A-Za-z]:)?(?:/[\w.\-]+){2,}"), "<PATH>"),
    (re.compile(r"(?<![\w.])\d+(?:\.\d+)?"), "<N>"),
)

# Ordered keyword rules used to classify an event into a category.
CATEGORY_RULES = (
    ("Authentication", re.compile(r"\b(auth\w*|login|token|password|credential\w*|unauthori[sz]ed)\b")),
    ("Database", re.compile(r"\b(database|db\d*|sql|query|pool|deadlock)\b")),
    ("Payment", re.compile(r"\b(payment|gateway|checkout|billing|invoice)\b")),
    ("Filesystem", re.compile(r"\b(file|disk|directory|permission denied|no space)\b")),
    ("Network", re.compile(r"\b(smtp|socket|dns|http|timeout|refused|unreachable)\b")),
    ("Performance", re.compile(r"\b(slow|latency|took|memory|cpu)\b")),
)
DEFAULT_CATEGORY = "Application"


# --------------------------------------------------------------------------
# Data structures
# --------------------------------------------------------------------------
class LogParseError(Exception):
    """Raised in strict mode when a line cannot be parsed."""


@dataclass
class LogEvent:
    timestamp: datetime
    level: str
    module: str
    message: str
    line_no: int = 0
    details: list = field(default_factory=list)  # stack-trace lines
    category: str = DEFAULT_CATEGORY

    @property
    def signature(self) -> str:
        """Normalised message used to group recurring errors."""
        return normalize_message(self.message)


@dataclass
class ParseStats:
    """Counters filled in while the log is being streamed."""
    total_lines: int = 0
    parsed: int = 0
    continuation: int = 0
    blank: int = 0
    malformed: int = 0


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def normalize_message(message: str) -> str:
    """Replace variable parts of a message with placeholders.

    >>> normalize_message("Timeout after 30s on host 10.0.0.5")
    'Timeout after <N>s on host <IP>'
    """
    for pattern, placeholder in _NORMALIZERS:
        message = pattern.sub(placeholder, message)
    return message.strip()


def classify_event(module: str, message: str) -> str:
    """Return a category name for an event based on keywords."""
    text = f"{module} {message}".lower()
    for category, pattern in CATEGORY_RULES:
        if pattern.search(text):
            return category
    return DEFAULT_CATEGORY


def _parse_timestamp(text: str) -> datetime:
    text = text.replace("T", " ").replace(",", ".")
    fmt = "%Y-%m-%d %H:%M:%S.%f" if "." in text else "%Y-%m-%d %H:%M:%S"
    return datetime.strptime(text, fmt)


def normalize_level(level: str) -> Optional[str]:
    level = level.upper()
    level = LEVEL_ALIASES.get(level, level)
    return level if level in LEVELS else None


def parse_line(line: str, line_no: int = 0) -> Optional[LogEvent]:
    """Parse a single line. Returns ``None`` if it is not a valid log entry."""
    for pattern in LINE_PATTERNS:
        match = pattern.match(line)
        if not match:
            continue
        level = normalize_level(match["level"])
        if level is None:
            return None
        try:
            ts = _parse_timestamp(match["ts"])
        except ValueError:          # e.g. month 13 or day 40
            return None
        module, message = match["module"], match["message"].strip()
        return LogEvent(
            timestamp=ts,
            level=level,
            module=module,
            message=message,
            line_no=line_no,
            category=classify_event(module, message),
        )
    return None


# --------------------------------------------------------------------------
# Streaming reader (generator)
# --------------------------------------------------------------------------
def read_log(path, *, strict: bool = False, stats: Optional[ParseStats] = None) -> Iterator[LogEvent]:
    """Lazily yield :class:`LogEvent` objects from ``path``.

    * Unparseable lines are logged and counted (or raise in ``strict`` mode).
    * Indented / traceback lines are attached to the previous event.
    * Raises ``FileNotFoundError``/``PermissionError`` when the file is
      unreadable (on the first ``next()`` because this is a generator).
    """
    stats = stats if stats is not None else ParseStats()
    path = Path(path)
    logger.info("Opening log file: %s", path)

    # errors="replace" -> a stray bad byte never aborts the whole analysis
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        pending: Optional[LogEvent] = None
        for line_no, raw in enumerate(handle, start=1):
            stats.total_lines += 1
            line = raw.rstrip("\r\n")

            if not line.strip():
                stats.blank += 1
                continue

            event = parse_line(line, line_no)
            if event is not None:
                if pending is not None:
                    yield pending
                pending = event
                stats.parsed += 1
            elif pending is not None and CONTINUATION_RE.match(line):
                pending.details.append(line.strip())
                stats.continuation += 1
            else:
                stats.malformed += 1
                logger.warning("Line %d could not be parsed: %.80s", line_no, line)
                if strict:
                    raise LogParseError(f"line {line_no}: {line[:80]!r}")

        if pending is not None:
            yield pending

    logger.info(
        "Finished reading: %d lines, %d events, %d malformed",
        stats.total_lines, stats.parsed, stats.malformed,
    )
