"""Command line entry point:  python -m log_analyzer <logfile> [options]"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from . import __version__
from .analyzer import analyze, find_alerts
from .parser import LogParseError, ParseStats, read_log
from .report_html import write_html_report
from .report import (build_report, print_console_summary, write_summary_csv,
                     write_text_report, write_top_errors_csv)

logger = logging.getLogger("log_analyzer")

EXIT_OK, EXIT_ERROR, EXIT_NO_DATA = 0, 1, 2


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="log_analyzer",
        description="Analyse an application log and report errors/warnings.",
    )
    p.add_argument("logfile", help="path to the .log file to analyse")
    p.add_argument("-n", "--top", type=int, default=5, help="how many top errors to list (default 5)")
    p.add_argument("-o", "--output-dir", default="output", help="where reports and app log go (default ./output)")
    p.add_argument("--strict", action="store_true", help="abort on the first malformed line")
    p.add_argument("--quiet", action="store_true", help="do not print the console summary")
    p.add_argument("-v", "--verbose", action="store_true", help="show INFO/WARNING logging on the console")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def setup_logging(log_file: Path, verbose: bool = False) -> None:
    """Application log goes to a file; console only shows problems (or all if -v)."""
    root = logging.getLogger("log_analyzer")
    root.setLevel(logging.DEBUG)
    for old in list(root.handlers):      # close previous file handles
        old.close()
        root.removeHandler(old)

    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    file_handler.setLevel(logging.INFO)

    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    console.setLevel(logging.INFO if verbose else logging.ERROR)

    root.addHandler(file_handler)
    root.addHandler(console)


def run(args: argparse.Namespace) -> int:
    out_dir = Path(args.output_dir)
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        setup_logging(out_dir / "log_analyzer.log", args.verbose)
    except OSError as exc:
        print(f"ERROR: cannot create output directory '{out_dir}': {exc}", file=sys.stderr)
        return EXIT_ERROR

    if args.top < 1:
        logger.error("--top must be at least 1")
        return EXIT_ERROR

    logger.info("=== log_analyzer %s started: %s ===", __version__, args.logfile)
    stats = ParseStats()
    try:
        # read_log() is a generator, analyze() pulls events one by one
        result = analyze(read_log(args.logfile, strict=args.strict, stats=stats))
    except FileNotFoundError:
        logger.error("Log file not found: %s", args.logfile)
        return EXIT_ERROR
    except IsADirectoryError:
        logger.error("Expected a file but got a directory: %s", args.logfile)
        return EXIT_ERROR
    except PermissionError:
        logger.error("Permission denied reading: %s", args.logfile)
        return EXIT_ERROR
    except LogParseError as exc:
        logger.error("Strict mode - malformed line, aborting: %s", exc)
        return EXIT_ERROR
    except OSError as exc:
        logger.error("I/O error while reading %s: %s", args.logfile, exc)
        return EXIT_ERROR

    if result.total_events == 0:
        logger.error("No valid log entries found in %s", args.logfile)
        return EXIT_NO_DATA

    alerts = find_alerts(result)
    report = build_report(result, alerts, source=str(args.logfile), stats=stats, top_n=args.top)

    try:
        write_text_report(report, out_dir / "analysis_report.txt")
        write_top_errors_csv(result, out_dir / "top_errors.csv", top_n=max(args.top, 10))
        write_summary_csv(result, out_dir / "summary.csv")
        write_html_report(result, alerts, out_dir / "report.html", source=str(args.logfile),
                          stats=stats, top_n=args.top)
    except OSError as exc:
        logger.error("Could not write report files: %s", exc)
        return EXIT_ERROR

    if not args.quiet:
        print_console_summary(report)
        print(f"\nFiles written to: {out_dir.resolve()}")
    logger.info("=== finished OK ===")
    return EXIT_OK


def main(argv=None) -> int:
    return run(build_arg_parser().parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())