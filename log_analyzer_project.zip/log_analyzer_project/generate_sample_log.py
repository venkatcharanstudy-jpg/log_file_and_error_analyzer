"""Generate a realistic, reproducible sample log (sample_logs/app.log)."""
import random
from datetime import datetime, timedelta
from pathlib import Path

random.seed(42)
START = datetime(2026, 10, 19, 8, 0, 0)

def ip(): return f"10.0.{random.randint(0, 3)}.{random.randint(2, 250)}"

INFO = [
    ("web.server", lambda: f"Request GET /api/orders completed in {random.randint(20, 400)}ms (status=200)"),
    ("web.server", lambda: f"Request POST /api/cart completed in {random.randint(30, 300)}ms (status=201)"),
    ("auth.service", lambda: f"User login successful user_id={random.randint(1000, 9999)}"),
    ("scheduler", lambda: "Job inventory_sync started"),
    ("cache", lambda: f"Cache refreshed: {random.randint(100, 900)} keys"),
]
WARN = [
    ("database.pool", lambda: f"Connection pool usage at {random.randint(80, 95)}% (host=db01)"),
    ("web.server", lambda: f"Slow request GET /api/reports took {random.randint(2000, 6000)}ms"),
    ("auth.service", lambda: f"Failed login attempt for user_id={random.randint(1000, 9999)} from {ip()}"),
    ("disk.monitor", lambda: f"Disk usage at {random.randint(85, 93)}% on /var/data"),
    ("payment.gateway", lambda: f"Retrying payment request attempt {random.randint(1, 3)}/3"),
]
TRACE = ["Traceback (most recent call last):",
         '  File "/app/orders/views.py", line 88, in get_order',
         "    return order['customer_id']",
         "KeyError: 'customer_id'"]
ERR = [
    ("database.connection", lambda: f"Connection timeout after {random.choice([30, 30, 45, 60])}s (host=db01)", None, 8),
    ("payment.gateway", lambda: f"Payment declined: gateway returned HTTP 502 for order {random.randint(50000, 59999)}", None, 5),
    ("auth.service", lambda: f"Invalid token for user_id={random.randint(1000, 9999)}", None, 4),
    ("file.storage", lambda: f"Failed to write file /var/data/exports/report_{random.randint(1, 99)}.csv: Permission denied", None, 3),
    ("web.server", lambda: "Unhandled exception in /api/orders: KeyError 'customer_id'", TRACE, 3),
    ("mail.service", lambda: f"SMTP connection refused by {ip()}:25", None, 2),
]
CRIT = ("database.connection", "Database unreachable - failover to replica db02 initiated")

events = []  # (timestamp, level, module, message, extra_lines)
def rnd_time(lo=0, hi=6 * 3600):
    return START + timedelta(seconds=random.randint(lo, hi), milliseconds=random.randint(0, 999))

for _ in range(300):
    m, f = random.choice(INFO);  events.append((rnd_time(), "INFO", m, f(), None))
for _ in range(60):
    m, f = random.choice(WARN);  events.append((rnd_time(), "WARNING", m, f(), None))
weights = [e[3] for e in ERR]
for _ in range(55):
    m, f, tr, _w = random.choices(ERR, weights)[0]
    events.append((rnd_time(), "ERROR", m, f(), tr))
# error burst: database trouble between 11:00 and 11:20
for _ in range(22):
    events.append((rnd_time(3 * 3600, 3 * 3600 + 1200), "ERROR", "database.connection",
                   f"Connection timeout after {random.choice([30, 45])}s (host=db01)", None))
events.append((START + timedelta(hours=3, minutes=21), "CRITICAL", CRIT[0], CRIT[1], None))
events.sort(key=lambda e: e[0])

lines = []
for ts, lvl, mod, msg, extra in events:
    stamp = ts.strftime("%Y-%m-%d %H:%M:%S,") + f"{ts.microsecond // 1000:03d}"
    lines.append(f"{stamp} | {lvl:<8} | {mod} | {msg}")
    if extra:
        lines.extend(extra)

# a few corrupted lines, to demonstrate error handling
for pos, junk in ((40, "*** log rotated ***"), (150, "garbled##line without format"),
                  (300, "2026-13-45 99:99:99 | ERROR | bad.date | impossible timestamp")):
    lines.insert(pos, junk)

out = Path(__file__).parent / "sample_logs" / "app.log"
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"Wrote {len(lines)} lines to {out}")
