import tempfile
import unittest
from pathlib import Path

from log_analyzer.parser import (LogParseError, ParseStats, classify_event,
                                 normalize_message, parse_line, read_log)

PIPE = "2026-10-19 08:15:32,123 | ERROR | database.connection | Connection timeout after 30s (host=db01)"
BRACKET = "2026-10-19 08:15:32 [WARN] web.server: Slow request took 2500ms"


def write_tmp(text: str) -> Path:
    tmp = tempfile.NamedTemporaryFile("w", suffix=".log", delete=False, encoding="utf-8")
    tmp.write(text)
    tmp.close()
    return Path(tmp.name)


class ParseLineTests(unittest.TestCase):
    def test_pipe_format(self):
        ev = parse_line(PIPE, 7)
        self.assertEqual(ev.level, "ERROR")
        self.assertEqual(ev.module, "database.connection")
        self.assertEqual(ev.timestamp.hour, 8)
        self.assertEqual(ev.timestamp.microsecond, 123000)
        self.assertEqual(ev.line_no, 7)
        self.assertIn("timeout", ev.message)

    def test_bracket_format_and_level_alias(self):
        ev = parse_line(BRACKET)
        self.assertEqual(ev.level, "WARNING")          # WARN -> WARNING
        self.assertEqual(ev.module, "web.server")

    def test_invalid_lines_return_none(self):
        for bad in ["", "random text", "2026-13-45 99:99:99 | ERROR | m | x",
                    "2026-10-19 08:00:00 | VERBOSE | m | x"]:
            self.assertIsNone(parse_line(bad), bad)


class NormalizeAndClassifyTests(unittest.TestCase):
    def test_numbers_ips_paths_are_normalised(self):
        self.assertEqual(normalize_message("Timeout after 30s on 10.0.0.5"),
                         "Timeout after <N>s on <IP>")
        self.assertEqual(normalize_message("Cannot open /var/data/x.csv"), "Cannot open <PATH>")
        self.assertEqual(normalize_message("user_id=4821 failed"), "user_id=<N> failed")

    def test_same_error_different_values_share_signature(self):
        a = normalize_message("Connection timeout after 30s (host=db01)")
        b = normalize_message("Connection timeout after 45s (host=db01)")
        self.assertEqual(a, b)

    def test_classification(self):
        self.assertEqual(classify_event("database.connection", "Connection timeout"), "Database")
        self.assertEqual(classify_event("auth.service", "Invalid token"), "Authentication")
        self.assertEqual(classify_event("file.storage", "Permission denied"), "Filesystem")
        self.assertEqual(classify_event("mail.service", "SMTP connection refused"), "Network")
        self.assertEqual(classify_event("web.server", "Unhandled exception"), "Application")


class ReadLogTests(unittest.TestCase):
    def test_is_a_generator(self):
        path = write_tmp(PIPE + "\n")
        self.assertTrue(hasattr(read_log(path), "__next__"))

    def test_stats_stacktrace_and_malformed(self):
        text = "\n".join([
            PIPE,
            "Traceback (most recent call last):",
            '  File "x.py", line 1, in f',
            "KeyError: 'a'",
            "",
            "garbage line",
            BRACKET,
        ]) + "\n"
        stats = ParseStats()
        events = list(read_log(write_tmp(text), stats=stats))
        self.assertEqual(len(events), 2)
        self.assertEqual(len(events[0].details), 3)       # traceback attached
        self.assertEqual(stats.parsed, 2)
        self.assertEqual(stats.continuation, 3)
        self.assertEqual(stats.malformed, 1)
        self.assertEqual(stats.blank, 1)
        self.assertEqual(stats.total_lines, 7)

    def test_strict_mode_raises(self):
        path = write_tmp(PIPE + "\nnot a log line\n")
        with self.assertRaises(LogParseError):
            list(read_log(path, strict=True))

    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            list(read_log("/no/such/file.log"))

    def test_bad_bytes_do_not_crash(self):
        path = Path(tempfile.mkstemp(suffix=".log")[1])
        path.write_bytes(PIPE.encode() + b"\n\xff\xfe broken bytes\n")
        self.assertEqual(len(list(read_log(path))), 1)


if __name__ == "__main__":
    unittest.main()
