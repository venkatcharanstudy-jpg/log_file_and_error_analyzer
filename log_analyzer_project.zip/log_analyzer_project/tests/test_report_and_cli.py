import csv
import tempfile
import unittest
from pathlib import Path

from log_analyzer.analyzer import analyze, find_alerts
from log_analyzer.main import main
from log_analyzer.parser import read_log
from log_analyzer.report import build_report, write_summary_csv, write_top_errors_csv
from log_analyzer.report_html import write_html_report

SAMPLE = Path(__file__).resolve().parent.parent / "sample_logs" / "app.log"


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.result = analyze(read_log(SAMPLE))
        self.tmp = Path(tempfile.mkdtemp())

    def test_report_text_contains_sections(self):
        text = build_report(self.result, find_alerts(self.result), source="app.log")
        for section in ("OVERVIEW", "TOP 5 RECURRING ERRORS", "ERRORS BY MODULE", "ALERTS"):
            self.assertIn(section, text)

    def test_top_errors_csv(self):
        path = write_top_errors_csv(self.result, self.tmp / "t.csv", top_n=3)
        with open(path, newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[0]["rank"], "1")
        counts = [int(r["count"]) for r in rows]
        self.assertEqual(counts, sorted(counts, reverse=True))

    def test_summary_csv(self):
        path = write_summary_csv(self.result, self.tmp / "s.csv")
        content = path.read_text(encoding="utf-8")
        self.assertIn("overview,total_events", content)
        self.assertIn("level,ERROR", content)

    def test_html_report(self):
        path = write_html_report(self.result, find_alerts(self.result), self.tmp / "r.html",
                                 source="app.log", top_n=5)
        html = path.read_text(encoding="utf-8")
        self.assertTrue(html.startswith("<!DOCTYPE html>"))
        for text in ("Log Analysis Report", "Top 5 recurring errors", "Errors by hour"):
            self.assertIn(text, html)
        self.assertIn("Connection timeout after &lt;N&gt;s", html)   # HTML-escaped


class CliTests(unittest.TestCase):
    def test_success_creates_all_outputs(self):
        out = Path(tempfile.mkdtemp())
        code = main([str(SAMPLE), "-o", str(out), "--quiet"])
        self.assertEqual(code, 0)
        for name in ("analysis_report.txt", "top_errors.csv", "summary.csv", "report.html", "log_analyzer.log"):
            self.assertTrue((out / name).exists(), name)

    def test_missing_file_returns_error_code(self):
        out = tempfile.mkdtemp()
        self.assertEqual(main(["/no/such.log", "-o", out, "--quiet"]), 1)

    def test_directory_instead_of_file(self):
        out = tempfile.mkdtemp()
        self.assertEqual(main([out, "-o", out, "--quiet"]), 1)

    def test_empty_log_returns_no_data_code(self):
        empty = Path(tempfile.mkdtemp()) / "empty.log"
        empty.write_text("nothing useful here\n", encoding="utf-8")
        self.assertEqual(main([str(empty), "-o", tempfile.mkdtemp(), "--quiet"]), 2)

    def test_strict_mode_fails_on_sample(self):
        self.assertEqual(main([str(SAMPLE), "-o", tempfile.mkdtemp(), "--quiet", "--strict"]), 1)


if __name__ == "__main__":
    unittest.main()