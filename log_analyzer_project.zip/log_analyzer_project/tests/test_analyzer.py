import unittest
from datetime import datetime

from log_analyzer.analyzer import analyze, find_alerts
from log_analyzer.parser import LogEvent, classify_event


def ev(level, msg, module="m", hour=9, minute=0):
    return LogEvent(datetime(2026, 10, 19, hour, minute), level, module, msg,
                    category=classify_event(module, msg))


class AnalyzerTests(unittest.TestCase):
    def setUp(self):
        self.events = [
            ev("INFO", "ok"), ev("INFO", "ok"),
            ev("WARNING", "Disk at 90%"), ev("WARNING", "Disk at 91%"),
            ev("ERROR", "Timeout after 30s", "db", 9, 1),
            ev("ERROR", "Timeout after 45s", "db", 9, 30),
            ev("ERROR", "Timeout after 60s", "db", 10, 5),
            ev("ERROR", "Invalid token for user_id=1", "auth", 10, 7),
            ev("CRITICAL", "Out of memory", "core", 11, 0),
        ]
        self.result = analyze(iter(self.events))      # works with any iterable

    def test_counts(self):
        r = self.result
        self.assertEqual(r.total_events, 9)
        self.assertEqual(r.level_counts["INFO"], 2)
        self.assertEqual(r.warning_count, 2)
        self.assertEqual(r.error_count, 5)             # ERROR + CRITICAL
        self.assertAlmostEqual(r.error_rate, 5 / 9)

    def test_top_errors_group_by_signature(self):
        top = self.result.top_errors(2)
        self.assertEqual(top[0].signature, "Timeout after <N>s")
        self.assertEqual(top[0].count, 3)
        self.assertEqual(top[0].rank, 1)
        self.assertAlmostEqual(top[0].percent, 60.0)
        self.assertEqual(top[0].first_seen, datetime(2026, 10, 19, 9, 1))
        self.assertEqual(top[0].last_seen, datetime(2026, 10, 19, 10, 5))

    def test_warnings_tracked_separately(self):
        self.assertEqual(self.result.top_warnings(1)[0].count, 2)

    def test_group_counters(self):
        self.assertEqual(self.result.module_errors["db"], 3)
        self.assertEqual(self.result.hourly_errors["2026-10-19 09:00"], 2)
        self.assertEqual(self.result.peak_error_hour[0], "2026-10-19 09:00")
        self.assertEqual(self.result.first_timestamp, datetime(2026, 10, 19, 9, 0))

    def test_empty_input(self):
        r = analyze([])
        self.assertEqual(r.total_events, 0)
        self.assertEqual(r.error_rate, 0.0)
        self.assertEqual(r.top_errors(), [])
        self.assertIsNone(r.peak_error_hour)

    def test_alerts(self):
        alerts = find_alerts(self.result, error_rate_threshold=0.5, repeat_threshold=3)
        text = " | ".join(alerts)
        self.assertIn("CRITICAL", text)
        self.assertIn("High error rate", text)
        self.assertIn("Recurring error x3", text)

    def test_no_alerts_when_healthy(self):
        healthy = analyze([ev("INFO", "ok") for _ in range(20)])
        self.assertEqual(find_alerts(healthy), [])


if __name__ == "__main__":
    unittest.main()
