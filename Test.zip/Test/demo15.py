
""" this the tool which is used for costool"""
import time 
class vendor :
    def __init__(self,en,gst):
        self.en=en
        self.gst=gst
        print('sucessfull created the vendor ')
    def billing (self,pn,q,t=0.0):
        self.pn=pn
        self.q=q
        self.t=t
        if isinstance(self.q, (int, float)):
            quantity = float(self.q)
        else:
            qty_text = ''.join(ch for ch in str(self.q) if ch.isdigit() or ch == '.')
            quantity = float(qty_text) if qty_text else 0.0
        self.total=quantity*self.t
        self.tax=0.18
        self.gs=(self.total*self.tax)+self.total
        with open ('vendor.log','a') as file:
            s1 =f'vendor name : {self.en} GST : {self.gst}'
            s2= f'product name : {self.pn} quantity : {self.q}'
            s3=f'product cost {self.t} Total(including tax){self.gs}'
            s4=f'po date : {time.ctime()}\n'
            file.write(s1+s2+s3+s4)
        file.close()

