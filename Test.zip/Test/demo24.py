import requests as r
import json as j

url2 = 'https://api.github.com/users'

rs = r.get(url2)

print(rs.status_code)

t = rs.text
data = j.loads(t)

print(data)