


#### Single ineritace
class a:
    pname='honey'
    pcost=90 
    pqty=30
    def display(self):
        print('Display the a details')
class b(a):
    cname = 'Arjun'
    cid='123'
    pqty='5'
    def display(self):
        print('Display the b details')
        super().display()
obj=b()
# print(obj.pname)
# print(obj.cid)
# print(obj.pqty)

obj.display()


