

import sqlite3 as s
d=s.connect('test1db')
m=d.cursor()
m.execute('insert into test(id,name,cost) values(?,?,?)', (101, 'Boost', 200))
m.execute('insert into test(id,name,cost) values(?,?,?)', (102, 'Horlick', 300))
m.execute('insert into test(id,name,cost) values(?,?,?)', (101, 'Biryani', 500))
d.commit()
for i in m.execute('select distinct(id),name,cost from test'):
    print(i)

m.close()
d.close()
