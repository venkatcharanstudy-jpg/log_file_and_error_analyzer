
# file = open('c:\\users\\Admin\\Downloads\\emp.csv', 'r')
# s = file.readlines()
# file.close()
# f=open('demo.csv','w')
# for i in s:
#     if 'sales' in i:
#         f.write(i+'\n')
# f.close()


# with open('c:\\users\\Admin\\Downloads\\emp.csv', 'r') as f:
#     s=f.readlines()
#     for i in s:
#         print(i,end='\n')
#     f.close()