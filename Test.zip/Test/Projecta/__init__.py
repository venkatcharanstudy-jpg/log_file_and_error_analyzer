# #### OOPS 
# class a :
#     app_name = 'dev'
#     version = 1.0
# del(a.version)
# a.app_name='Modren dev'
# a.version=1.1
# print(a.app_name,a.version)
# print(dir(a))
# print('\n')
# for i in a.__dict__:
#     print(f'{i}                      -       {a.__dict__.get(i)}')




class a:
    app_name='dev'
    version = 1.1

b=a()
print(b.app_name,a.app_name)
b.app_name='mod'
print(b.app_name,a.app_name)
a.app_name='dev 2.0 '
print(b.app_name,a.app_name)