def f2():
    return False