from sub1.demo1 import f1
print(f1())