def f1():
    return True