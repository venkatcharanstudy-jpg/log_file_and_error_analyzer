# class myacess:
#      aaa=100
#      def sum1(self):
#         print(self.aaa)
# class a(myacess):
#      aaaa=1000
#      def acess (self):
#           print(self.aaaa+self.aaa)
#         # print(100)
# a.sum1(a)
# a.acess(a)
# b= a()
# b.acess()



class En1:
    def __init__(self,en,dept):
        self.en = en 
        self.dept = dept
    def display(self):
        print(f'emp name {self.en}\n ,emp dept{self.dept}\n')
b= En1('Arjun','HR')
b.display()