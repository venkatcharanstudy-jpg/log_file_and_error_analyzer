

# file=open('c:\\users\\Admin\\Downloads\\emp.csv','r')
# # s=file.read()
# p=file.readlines()
# file.close()
# print(p[:4])


# file = open('cha.log','w')
# file.write('Hello world\n')
# file.write ('Hello world\n')
# file.close()


# file=open('c:\\users\\Admin\\Downloads\\emp.csv','r')
# s=file.read()
# file2=open('char.log','a')
# file2.write(s)
# file2.close()
# file.close()


# file2=open('char.log','a')
# file1=open('cha.log','r')
# s=file1.read()
# file2.write(s)
# file2.close()
# file1.close()