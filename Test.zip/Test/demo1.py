# # # # app_name = 'TestAPP'
# # # # running_port_number = 123
# # # # app_version=1.5
# # # # running_status=True
# # # # print(f"App Name: {app_name}, Running Port: {running_port_number}, Version: {app_version}, Status: {running_status}")
# # # # print("app_name:", app_name, 'running on port', running_port_number, 'with version', app_version, 'and status', running_status)
# # # # print(f'''App Name: {app_name}
# # # # ----------------------------------------------
# # # #           Running Port: {running_port_number}
# # # # ----------------------------------------------
# # # #           Version: {app_version}
# # # # ----------------------------------------------
# # # #           Status: {running_status}
# # # # ----------------------------------------------''')


# # # # s1=40
# # # # print(int(s1))
# # # # print(float(s1))
# # # # print(str(s1))
# # # # s='1000\n'
# # # # print(int(s[:-1])*0.18)


# # # app_name=input("Enter the App Name:   ")
# # # running_port_number:int(input(f"Enter {app_name} port number"))
# # # app_version=float(input(f"Enter {app_name} version"))
# # # running_status=bool(int(input(f"Enter {app_name} status (1 for True, 0 for False)")))   
# # # print(f'''App Name: {app_name}
# # # ----------------------------------------------
# # #           Running Port: {running_port_number}
# # # ----------------------------------------------
# # #           Version: {app_version}
# # # ----------------------------------------------
# # #           Status: {running_status}
# # # ----------------------------------------------''')

# # p=input()
# # pq=int(input())
# # c=int(input())
# # GST=19
# # total_cost=(c*pq +( (c * GST / 100)*pq))
# # print(f"Product Name : {p}\n, No of QTys: {pq}\n, Total Cost: {c*pq}\n, TAX: {total_cost-(c*pq)}\n, Including Tax: {total_cost}\n,")
# app=input()
# port=int(input())
# if app=='grafana':
#     port=3000
# else:
#     app_name='demoAPP'
#     port=8000
# print(f"App Name: {app_name}, Running Port: {port}")

# app=input()
# if app=='grafana' or app=='prometheus' or app=='webauth':
#     if app=='grafana':
#         port=3000
#         config='/etc/grafana/'
#     elif app=='prometheus':
#         port=9090
#         config='/etc/prometheus.yml/'
#     elif app=='webauth':
#         port=5001
#         config='/etc/web2.0/auth.cfg'
# else:
#     app='demoAPP'
#     port=8000
#     config='/etc/demoapp.cdfg'
# print(f'''App Name: {app}\n, Running Port: {port}\n, Config File: {config}\n''')

# dict={'grafana':[3000, '/etc/grafana/'],
#       'prometheus':[9090, '/etc/prometheus.yml/'],
#       'webauth':[5001, '/etc/web2.0/auth.cfg'],
#       'demoAPP':[8000, '/etc/demoapp.cdfg']}
# print(dict.get(app,dict['demoAPP']))











