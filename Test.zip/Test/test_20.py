from demo20 import f1, f2

def test_f1():
    assert f1(10, 20) == 30
def test_f2():
    assert f2("venkat") == "VENKAT"


