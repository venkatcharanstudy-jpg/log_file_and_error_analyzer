def f1(a1: int, a2: int) -> int:
    return a1 + a2


def f2(a1: str) -> str:
    return a1.upper()
