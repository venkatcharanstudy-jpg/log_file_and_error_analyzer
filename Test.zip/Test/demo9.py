import time
file=open('pin_history.log','a')
count = 0
pin1='123'
while count<3:
    pin = input('Enter the Pin : ')
    if pin == pin1:
        print('Pin validated Sucessfully')
        file.write(f'Pin Sucessfully Validated - {time.ctime()}\n')
        break
    else:
        file.write(f'Invalid pin - {time.ctime()}\n')
    count+=1

if pin1!=int(pin):
    file.write(f'your pin blocked Sucessfully - {time.ctime()}\n')
    print('your pin blocked Sucessfully')
file.close()


