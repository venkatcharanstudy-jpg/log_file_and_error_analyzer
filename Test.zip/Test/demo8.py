def calculate_factorial(n):
	if n < 0:
		return None

	factorial = 1
	for value in range(2, n + 1):
		factorial *= value
	return factorial

n = int(input("Enter a non-negative integer: "))

result = calculate_factorial(n)
if result is None:
	print("Factorial is not defined for negative numbers.")
else:
	print(f"{n}! = {result}")
