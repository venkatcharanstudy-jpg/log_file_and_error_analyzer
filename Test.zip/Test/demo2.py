

pin = 8123
count = 0
while count < 3:
    pin1 = int(input("Enter PIN: "))
    if pin1 == pin:
        print('pin is matched', count)
        break
    count += 1
else:
    print('Pin blocked')

