# l1=[]
# count=0
# print('no of devices:',len(l1))
# while count<5:
#     i=input('Enter the Device Name :')
#     l1.append(i)
#     count+=1
# print('no of devices:', len(l1))
# for j in l1:
#     print(j)
# l2=input('Enter the Another Device Name :')
# if l2 in l1:
#     print('Device already exists at index:', l1.index(l2))
# else:
#     l1.append(l2)
#     print('Upadted list with l2:', l1)


l1=['101','raj','sales','pune',1000,
    '102','ram','marketing','mumbai',2000,
    '103','sita','hr','delhi',3000,
    '104','gita','finance','chennai',4000,
    '105','mohan','it','bangalore',5000]
for i,j,k,l,m in range(len(l1),5):
    print(l1[i],l1[j],l1[k],l1[l],l1[m])




