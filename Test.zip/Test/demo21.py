import pytest
import requests
@pytest.fixture
def input_data():
    r=requests.get('https://www.google.com')
    return r.status_code
def test_get_url(input_data):
    assert input_data==""