import json as j

a = j.loads('''{
    "name": "John Doe",
    "age": 30,
    "email": "johndoe@example.com",
    "isActive": true
}''')

print(a)