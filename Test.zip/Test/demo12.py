from functools import reduce
f1=open('C:\\Users\\Admin\\Downloads\\emp.csv','r')
l=f1.readlines()
f1.close()
total=0
print(l)
a=[ int(var.split(',')[-1]) for var in l if 'sales' in var]
print(sum(a)) 