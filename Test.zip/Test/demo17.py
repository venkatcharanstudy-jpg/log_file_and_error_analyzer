def v(name):
    l1=['a','e','i','o','u']
    v1=[]
    v2=[]
    name=name.lower()
    for i in name:
        if i in l1:
            v1.append(i)
        else:
            if i==' ':
                continue
            v2.append(i)
    return f'volwesl are : {v1}\nconsonants are : {v2}'
print(v('Venkat Charan Reddy'))