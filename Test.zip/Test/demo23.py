
import logging

logging.basicConfig(
    filename='ping_history.log',
    filemode='a',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
count = 0
pin1='123'
while count<3:
    pin = input('Enter the Pin : ')
    if pin == pin1:
        print('Pin validated Sucessfully')
        logging.info('Sucessfully created')
        break
    else:
        logging.warning('Entered the inccorect pin ')
    count+=1

if pin1!=int(pin):
    print('your pin blocked Sucessfully')
    logging.error('Pin blocked sucessfully')


