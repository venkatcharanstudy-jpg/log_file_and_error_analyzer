# import re
# s= ' 101, ayush,IOT,Cisco'
# print(bool(re.search('ayush',s)))
# if (re.search('venkat',s)):
#     print('it is present ')
#     print(s)
# else:
#     print('not poresent')



# import os,re
# file = os.listdir('C:\\Users\\Admin\\Documents\\Venkat')
# l1=[i for i in file if re.search('py$|log$',i)]
# print(l1)
# for i in file:
#     if re.search('py$|log$',i):
#         print(i)




