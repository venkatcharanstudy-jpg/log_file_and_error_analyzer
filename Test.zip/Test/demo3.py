# s='123456789'
# count=0
# for i in s:
#     count+=int(i)
# print(count)


# l1=['101','raj','sales','pune',1000,
#     '102','ram','marketing','mumbai',2000,
#     '103','sita','hr','delhi',3000,
#     '104','gita','finance','chennai',4000,
#     '105','mohan','it','bangalore',5000]
# c=0
# for i in range(0, len(l1), 5):
#     print('Employee:', l1[i+1].title(), '\t', 'Location:', l1[i+3].upper())
#     c+=l1[i+4]
# print('total emps cost:', c)

# l1=['101','raj','sales','pune',1000,
#     '102','ram','marketing','mumbai',2000,
#     '103','sita','hr','delhi',3000,
#     '104','gita','finance','chennai',4000,
#     '105','mohan','it','bangalore',5000]
# c=0
# for i in range(0, len(l1), 5):
#     print('Employee:', l1[i+1].title(), '\t', 'Location:', l1[i+3].upper())
#     c+=l1[i+4]
# print('total emps cost:', c)


# l1=[['101','raj'],['sales','pune',1000]]
# print(l1[0])
# print(l1[1][0])



# import pprint
# app_details = [['flask','version is 1.2',50000],
#                ['fastapi','version is 0.70',60000],
#                ['streamlit','version is 1.10',70000],
#                ['django','version is 3.2',80000]]
# app_details[2][2]=5000
# app_details.append(['web2.0','version is 2.0',90000])

# app_details[1].append('fastapi.config')
# print(app_details)
# l2=[]   
# for i in app_details:
#     l2.append(tuple(i))
#     print(i)
# pprint.pprint(l2)




# #### tupel of list
# l4=app_details.copy()
# l3=tuple(l4)
# print(l3)



# ##### tuple to tuple

# student = {
#     'name': 'Ayush',
#     'age': 20,
#     'course': 'Python',
#     'score': 85
# }
# print(student.get('name','Unknown'))


# import pprint
# d={}
# count=0
# while count<5:
#     a=input('Enter the alias name')
#     b=input('Enter the ip address')
#     if a in d:
#         print('Enter the Valid user name because host name already exists')
#     else:
#         d[a]=b
#         count+=1
# for i,j in d.items():
#     print('Host name:', i, '\t',':', 'IP address:', j)
# c=input('Enter the alias name ')
# if c in d:
#     d[c]='127.0.0.1'
# else:
#     d[c]='127.0.0.1'
# pprint.pprint(d)




# l1=['emp.csv:123:1KB:userA',
#    'r1.log:321:4KB:userB',
#    't1.java:435:3KB:userC',
#    'r2.log:345:5KB:userD']
# d={}
# for i in l1:
#     fname,fid,fsize,user=i.split(':')
#     d[fname]=[fid,fsize,user]
# for i in d:
#     print(i,':',d[i])