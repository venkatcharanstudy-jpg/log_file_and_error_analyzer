d={}
f=open('network.cfg','r')
s=f.readlines()
f.close()
print('\n')
for i in s:
    i=i.strip()
    a,b=i.split('=')
    d[a]=b
for i,j in d.items():
    print(f'{i}  -  {j}')
print('\n')
print('-----------------------------------------------\n')

d['Interface']='eth1'
d['onboot']='yes'
d['bootproto']='static'
d['IPADDR']='192.168.1.10'
d['PREFIX']=24
d['DNS2']='122.444.322.111'

for i,j in d.items():
    print(f'{i}  -  {j}')


f1=open('new_config.cfg','w')

for i,j in d.items():
    f1.write(f'{i} = {j}\n')
f1.close()