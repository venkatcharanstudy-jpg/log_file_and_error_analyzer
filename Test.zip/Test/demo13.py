class emp:
    emp_name = None
    emp_DOB = None
b1=emp()
b1.emp_name='Arjun'
b1.emp_DOB = '2-FEB'
print(f'emp name : {b1.emp_name} -  emp DOB : {b1.emp_DOB}\n')
b2=emp()
b2.emp_name = 'Venkat'
b2.emp_DOB = '24-JULY'
print(f'emp name : {b2.emp_name} -  emp DOB : {b2.emp_DOB}\n') 

emp.emp_dept=None
b2.emp_dept='HR'
b1.emp_dept='sales'

b3=emp()
b3.emp_DOB='24-JUNE'
b3.emp_name='Charan'
b3.emp_dept='dev'
print(f'emp name : {b1.emp_name} -  emp DOB : {b1.emp_DOB} - emp_dept : {b1.emp_dept}\n') 
print(f'emp name : {b2.emp_name} -  emp DOB : {b2.emp_DOB} - emp_dept : {b2.emp_dept}\n') 
print(f'emp name : {b3.emp_name} -  emp DOB : {b3.emp_DOB} - emp_dept : {b3.emp_dept}\n') 