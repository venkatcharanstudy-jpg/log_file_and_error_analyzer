# import logging
# logging.basicConfig(filename='demo.log',level=logging.INFO,
#                     format='%(asctime)s - %(levelname)s - %(message)s',
#                     datefmt='%y-%m-%d %H:%M:%S')
# logging.info('Application Process Started')
# logging.warning('5 records contaisn missing email')
# logging.error('App is in critical state')




